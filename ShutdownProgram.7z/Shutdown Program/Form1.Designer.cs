﻿namespace Shutdown_Program
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_thuchien = new System.Windows.Forms.Button();
            this.cb_thoigian = new System.Windows.Forms.CheckBox();
            this.tb_thoigian = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_thuchien
            // 
            this.btn_thuchien.Location = new System.Drawing.Point(145, 142);
            this.btn_thuchien.Name = "btn_thuchien";
            this.btn_thuchien.Size = new System.Drawing.Size(75, 23);
            this.btn_thuchien.TabIndex = 0;
            this.btn_thuchien.Text = "Thực Hiện";
            this.btn_thuchien.UseVisualStyleBackColor = true;
            this.btn_thuchien.Click += new System.EventHandler(this.btn_thuchien_Click);
            // 
            // cb_thoigian
            // 
            this.cb_thoigian.AutoSize = true;
            this.cb_thoigian.Location = new System.Drawing.Point(114, 103);
            this.cb_thoigian.Name = "cb_thoigian";
            this.cb_thoigian.Size = new System.Drawing.Size(15, 14);
            this.cb_thoigian.TabIndex = 1;
            this.cb_thoigian.UseVisualStyleBackColor = true;
            // 
            // tb_thoigian
            // 
            this.tb_thoigian.Location = new System.Drawing.Point(145, 98);
            this.tb_thoigian.Name = "tb_thoigian";
            this.tb_thoigian.Size = new System.Drawing.Size(75, 20);
            this.tb_thoigian.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Thời gian tắt máy:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 280);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_thoigian);
            this.Controls.Add(this.cb_thoigian);
            this.Controls.Add(this.btn_thuchien);
            this.Name = "Form1";
            this.Text = "Shutdown";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_thuchien;
        private System.Windows.Forms.CheckBox cb_thoigian;
        private System.Windows.Forms.TextBox tb_thoigian;
        private System.Windows.Forms.Label label1;
    }
}

